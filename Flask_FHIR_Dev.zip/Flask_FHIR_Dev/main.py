from flask import Flask, render_template
from flask.helpers import request

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST', 'GET']) # This function is called on the button click event
def testFunctie():
    if request.method == "POST":
        data = request.get_json() # POST data
        return data.upper()
        

if __name__ == "__main__":
    app.run(debug=False)