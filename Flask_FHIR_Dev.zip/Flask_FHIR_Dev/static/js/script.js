$("#button").on("click", function(){
    var input = $("#input").val(); 
    $.ajax({
      type: "POST", 
      url: "/predict", 
      data: JSON.stringify(input),
      contentType: "application/json",
      dataType: 'text',
    }).done(function(data) {
      alert("Hello " + data);
    })
    .fail(function() {
      alert( "error" );
    });
})


